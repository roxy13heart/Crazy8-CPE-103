/**
 * @author Austin Quick
 * @version 10-02-2014
 */

import java.util.EmptyStackException;
import java.util.Scanner;

public class LStackDriver {

    public final static String MENU = WRITE_MENU();

    public static String WRITE_MENU() {
        return "Choose one of the following operations:\n" +
                "- push/add (enter the letter a)\n" +
                "- pop/delete (enter the letter d)\n" +
                "- peek (enter the letter p)\n" +
                "- check if the list is empty (enter the letter e)\n" +
                "- Quit (enter the letter q)";
    }

    public static void main(String[] args) {
        LStack<Integer> stack = new LStack<>();
        Scanner scanner = new Scanner(System.in);
        System.out.println(MENU);
        char input;
        while (true) {
            System.out.print("Please enter your selection: ");
            input = Character.toLowerCase(scanner.next().charAt(0));
            switch (input) {
                case ('q') : {
                    while (!stack.isEmpty()) {
                        System.out.println(stack.pop());
                    }
                    System.exit(0);
                } break;

                case ('a') : {
                    System.out.print("Enter a value: ");
                    if (scanner.hasNextInt()) {
                        Integer i = scanner.nextInt();
                        stack.push(i);
                        System.out.println(i + " pushed in.");
                    }
                    else {
                        scanner.next();
                        System.out.println("Invalid input.");
                    }
                } break;

                case ('d') : {
                    try {
                        System.out.println(stack.pop() + " popped out.");
                    } catch (EmptyStackException ese) {
                        System.out.println("Invalid operation on an empty stack.");
                    }
                } break;

                case ('p') : {
                    try {
                        System.out.println(stack.peek() + " on top.");
                    } catch (EmptyStackException ese) {
                        System.out.println("Invalid operation on an empty stack.");
                    }
                } break;

                case ('e') : {
                    System.out.println(stack.isEmpty() ? "Empty." : "Not Empty.");
                } break;

                default : {
                    System.out.println("Invalid choice.");
                }
            }

        }
    }
}
