/**
 * @author Austin Quick
 * @version 10-02-2014
 */

import java.util.Scanner;

public class StringChecker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input;
        while (true) {
            input = "";
            System.out.println("Input:");
            input = scanner.nextLine();
            System.out.println(isBalanced(input) ? "Balanced." : "Unbalanced");
            System.out.print("Again? (0/1): ");
            if (scanner.hasNextInt()) {
                if (scanner.nextInt() != 1) {
                    break;
                }
            }
            else {
                break;
            }
            scanner.nextLine();
        }
    }

    public final static char BRACE_OPEN = '[', BRACE_CLOSE = ']',
            BRACKET_OPEN = '{', BRACKET_CLOSE = '}',
            PAREN_OPEN = '(', PAREN_CLOSE = ')';

    public static boolean isBalanced(String input) {
        LStack<Character> bbpStack = new LStack<>();
        for (char c : input.toCharArray()) {
            if (isOpeningBBP(c)) {
                bbpStack.push(c);
            }
            else if (isClosingBBP(c)) {
                if (!bbpStack.isEmpty() && isMatch(bbpStack.peek(), c)) {
                    bbpStack.pop();
                }
                else {
                    return false;
                }
            }
        }
        return bbpStack.isEmpty();
    }

    private static boolean isOpeningBBP(char c) {
        return c == BRACE_OPEN || c == BRACKET_OPEN || c == PAREN_OPEN;
    }

    private static boolean isClosingBBP(char c) {
        return c == BRACE_CLOSE || c == BRACKET_CLOSE || c == PAREN_CLOSE;
    }

    private static boolean isMatch(char open, char close) {
        switch (open) {
            case (BRACE_OPEN) : return close == BRACE_CLOSE;
            case (BRACKET_OPEN) : return  close == BRACKET_CLOSE;
            case (PAREN_OPEN) : return close == PAREN_CLOSE;
            default : return false;
        }
    }
}
