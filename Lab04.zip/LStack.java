/**
 * @author Austin Quick
 * @version 10-02-2014
 */

import java.util.EmptyStackException;

public class LStack <T> {

    private class Node {
        public T element;
        public Node next;
        public Node(T element, Node next) {
            this.element = element;
            this.next = next;
        }
    }

    private Node firstNode;

    public LStack() {

    }

    public void push(T element) {
        firstNode = new Node(element, firstNode);
    }

    public T pop() {
        if (firstNode == null) {
            throw new EmptyStackException();
        }

        T poppedElement = firstNode.element;
        firstNode = firstNode.next;
        return poppedElement;
    }

    public T peek() {
        if (firstNode == null) {
            throw new EmptyStackException();
        }

        return firstNode.element;
    }

    public boolean isEmpty() {
        return firstNode == null;
    }
}